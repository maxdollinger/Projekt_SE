from django.apps import AppConfig


class ReportingSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reporting_system'
