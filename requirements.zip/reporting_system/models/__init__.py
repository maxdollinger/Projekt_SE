from .correction_report import CorrectionReport
from .document import Document